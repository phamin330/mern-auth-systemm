# MERN Auth System

Full-stack user auth system with React, Node.js, Express, MongoDB.

## Features
- Register/Login
- Email verification
- Forgot password
- Admin panel

## Deploy on Render
See instructions in README.